<?php $__env->startSection('title'); ?> Slider Create <?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
    <link href="<?php echo e(asset('admin_tmpl/css/bootstrap-fileinput.css')); ?>" rel="stylesheet" type="text/css"/>
    <link href="<?php echo e(asset('admin_tmpl/css/bootstrap-switch.min.css')); ?>" rel="stylesheet" type="text/css"/>
    <link href="<?php echo e(asset('admin_tmpl/css/datatables.min.css')); ?>" rel="stylesheet" type="text/css"/>
    <link href="<?php echo e(asset('admin_tmpl/css/datatables.bootstrap.css')); ?>" rel="stylesheet" type="text/css"/>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="slider_create_page">
        <!-- BEGIN PAGE TITLE-->
        <h1 class="page-title"> Create Slider
            <small>Here you can create new slider or banner</small>
        </h1>
        <!-- END PAGE TITLE-->


        <div class="sliders_form">
            <?php echo Form::open(['url' => 'admin/sliders', 'files' => true]); ?>

            <?php echo $__env->make('admin.sliders.form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <div class="form-actions">
                <button type="submit" class="btn green">Save</button>
            </div>
            <?php echo Form::close(); ?>

        </div>


    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
    <script src="<?php echo e(asset('admin_tmpl/js/bootstrap-fileinput.js')); ?>" type="text/javascript"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>