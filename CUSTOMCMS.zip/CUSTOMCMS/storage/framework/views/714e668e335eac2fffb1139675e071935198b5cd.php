<?php $__env->startSection('header'); ?>
    <link href="<?php echo e(asset('admin_tmpl/css/login.css')); ?>" rel="stylesheet" type="text/css"/>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- BEGIN LOGO -->
    <div class="login">
        <div class="logo">
            <a href="index.html">
                <img src="<?php echo e(asset('admin_tmpl/images/logo-big.png')); ?>" alt=""/> </a>
        </div>
        <!-- END LOGO -->
        <!-- BEGIN LOGIN -->
        <div class="content">
        <?php if(session('status')): ?>
            <div class="alert alert-success">
                <?php echo e(session('status')); ?>

            </div>
        <?php endif; ?>
        <!-- BEGIN FORGOT PASSWORD FORM -->
            <form class="forget-form" method="POST" action="<?php echo e(route('password.email')); ?>">
                <?php echo e(csrf_field()); ?>

                <h3>Forget Password ?</h3>
                <p> Enter your e-mail address below to reset your password. </p>
                <div class="form-group <?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                    <div class="input-icon">
                        <i class="fa fa-envelope"></i>
                        <input class="form-control placeholder-no-fix" type="text" autocomplete="off"
                               placeholder="Email" name="email" value="<?php echo e(old('email')); ?>" required/>
                        <?php if($errors->has('email')): ?>
                            <span class="help-block">
                                <?php echo e($errors->first('email')); ?>

                            </span>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="form-actions">
                    <a href="<?php echo e(url('/login')); ?>" class="btn red btn-outline">Back</a>
                    <button type="submit" class="btn green pull-right"> Submit</button>
                </div>
            </form>
            <!-- END FORGOT PASSWORD FORM -->
        </div>
        <!-- BEGIN COPYRIGHT -->
        <div class="copyright"> <?= date('Y') ?> &copy; Laracus - Reset your password page</div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('footer'); ?>
    <script src="<?php echo e(asset('admin_tmpl/js/jquery.backstretch.min.js')); ?>" type="text/javascript"></script>
    <script src="<?php echo e(asset('admin_tmpl/js/login.js')); ?>" type="text/javascript"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('auth.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>