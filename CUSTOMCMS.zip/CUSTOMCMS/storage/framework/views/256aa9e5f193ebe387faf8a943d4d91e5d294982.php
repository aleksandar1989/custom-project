<?php $__env->startSection('title'); ?> Categories  <?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="category_manage_page">
        <!-- BEGIN PAGE TITLE-->
        <h1 class="page-title"> Manage Categories
            <small>Here you can create, edit and delete categories</small>
        </h1>
        <!-- END PAGE TITLE-->
    </div>

    <section class="content">
        <div class="row">
            <!-- left column -->
            <div class="col-md-4">
                <!-- general form elements -->
                <div class="box box-primary">
                    <!-- form start -->
                    <?php echo Form::open(['url' => 'admin/terms']); ?>

                    <?php echo Form::hidden('taxonomy', 'category'); ?>

                    <div class="box-body">
                        <?php echo $__env->make('admin.terms.form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    </div><!-- /.box-body -->

                    <div class="box-footer">
                        <button type="submit" class="btn green">Add New Category</button>
                    </div>
                    <?php echo Form::close(); ?>

                </div><!-- /.box -->
            </div>

            <!-- right column -->
            <div class="col-md-8">

            </div><!-- /.col -->
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>