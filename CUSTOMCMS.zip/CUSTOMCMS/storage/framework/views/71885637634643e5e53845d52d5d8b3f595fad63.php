<div class="sidebar_item clearfix">
    <div class="form-group">
        <h3>Template</h3>
        <?php if(count($templates)): ?>
            <div class="md-radio-list">
                <?php $__currentLoopData = $templates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $template): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="md-radio">
                        <input type="radio" class="md-radiobtn" id="<?php echo e($key); ?>" name="template" value="<?php echo e($key); ?>" <?php echo e(isset($post) && $post->template == $key ? 'checked' : ''); ?> <?php echo e(!isset($post) && $key == 'default' ? 'checked' : ''); ?>>
                        <label for="<?php echo e($key); ?>">
                            <span class="inc"></span>
                            <span class="check"></span>
                            <span class="box"></span>  <?php echo e($template); ?> </label>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>
    </div>
</div>

<div class="sidebar_item clearfix">
    <div class="form-group">
        <h3>Parent</h3>
        <select name="parent_id" id="parent" class="form-control">
            <option value="0">No parent...</option>
            <?php if(count($postsLeveled)): ?>
                <?php $__currentLoopData = $postsLeveled; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $postLeveled): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if(!in_array($postLeveled['id'], isset($post) ? $post->getChildren(true) : [])): ?>
                        <option value="<?php echo e($postLeveled['id']); ?>"  <?php echo e(Input::old('parent_id') == $postLeveled['id'] || (isset($post) && $post->parent_id == $postLeveled['id']) ? 'selected' : ''); ?>>
                            <?php for($i = 0; $i < $postLeveled['level']; $i++): ?>&nbsp;&nbsp;&nbsp;&nbsp;<?php endfor; ?>
                            <?php echo e($postLeveled['title']); ?>

                        </option>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </select>
    </div>
</div>

<div class="sidebar_item clearfix">
    <div class="form-group spiner">
        <h3>Order</h3>
        <?php echo Form::input('number', 'order', null, ['min' => '0', 'class' => 'text-center order_input']); ?>

    </div>
</div>