<?php $__env->startSection('title'); ?> Users <?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
    <link href="<?php echo e(asset('admin_tmpl/css/bootstrap-switch.min.css')); ?>" rel="stylesheet" type="text/css"/>
    <link href="<?php echo e(asset('admin_tmpl/css/datatables.min.css')); ?>" rel="stylesheet" type="text/css"/>
    <link href="<?php echo e(asset('admin_tmpl/css/datatables.bootstrap.css')); ?>" rel="stylesheet" type="text/css"/>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="language_listing_page">
        <!-- BEGIN PAGE TITLE-->
        <h1 class="page-title"> Languages
            <small>Here you can see all languages</small>
        </h1>
        <!-- END PAGE TITLE-->

        <div class="table-scrollable">
            <table class="table table-hover">
                <thead>
                <tr>
                    <th> # </th>
                    <th> Code </th>
                    <th> Name </th>
                    <th> Delete  </th>
                </tr>
                </thead>
                <tbody>
                <?php if($languages->count()): ?>
                    <?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($language->id); ?></td>
                            <td><?php echo e($language->code); ?></td>
                            <td><?php echo e($language->name); ?></td>
                            <td class="cat-action">
                                <?php if($language->id != 1): ?>
                                    <?php echo Form::open(array('route' => array('languages.destroy', $language->id), 'method' => 'delete', 'onsubmit' => 'return confirm("Are you sure you want to delete this language?");')); ?>

                                    <button type="submit" class="btn btn-xs red">
                                        <i class="fa fa-remove"></i> Delete
                                    </button>
                                    <?php echo Form::close(); ?>

                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <td colspan="3">No languages to display.</td>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
    <script src="<?php echo e(asset('admin_tmpl/js/datatable.js')); ?>" type="text/javascript"></script>
    <script src="<?php echo e(asset('admin_tmpl/js/datatables.min.js')); ?>" type="text/javascript"></script>
    <script src="<?php echo e(asset('admin_tmpl/js/datatables.bootstrap.js')); ?>" type="text/javascript"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>