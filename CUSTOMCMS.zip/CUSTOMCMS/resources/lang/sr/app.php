<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Global Language Lines
    |--------------------------------------------------------------------------
    |
    |
    */

    'Login' => 'Prijavi se',
    'Register' => 'Registruj se',
    'Welcome' => 'Dobrodošli',
    'Login to your account' => 'Prijavite se',
    'Enter any username and password.' => 'Unesite korisnicko ime i lozinku',

];
