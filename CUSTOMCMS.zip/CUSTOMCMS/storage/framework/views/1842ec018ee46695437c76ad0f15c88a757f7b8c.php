<div class="form-group">
    <label for="name">Name</label>
    <?php echo Form::text('name', null, ['class' => 'form-control', 'id' => 'name', 'placeholder' => 'Enter name...']); ?>

</div>
<div class="form-group">
    <label for="slug">Slug</label>
    <?php echo Form::text('slug', null, ['class' => 'form-control', 'id' => 'slug', 'placeholder' => 'Enter slug...']); ?>

</div>
<div class="form-group">
    <label for="parent">Parent</label>
    <select name="parent" id="parent" class="form-control">
        <option value="0">None</option>
        <?php if(count($categories)): ?>
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if(!in_array($category['id'], isset($term) ? $term->taxonomy->getChildren(true) : [])): ?>
                    <option value="<?php echo e($category['id']); ?>" <?php echo e(Input::old('parent') == $category['id'] || (isset($term) && $term->taxonomy->parent_id == $category['id']) ? 'selected' : ''); ?>>
                        <?php for($i = 0; $i < $category['level']; $i++): ?>&nbsp;&nbsp;&nbsp;&nbsp;<?php endfor; ?>
                        <?php echo e($category['name']); ?>

                    </option>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </select>
</div>
<div class="form-group">
    <label for="template">Template</label>
    <select name="template" id="template" class="form-control">
        <?php if(count($templates)): ?>
            <?php $__currentLoopData = $templates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $template): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($key); ?>" <?php echo e(isset($term) && $term->template == $key ? 'selected' : ''); ?> <?php echo e(!isset($term) && $key == 'default' ? 'selected' : ''); ?>>
                    <?php echo e($template); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </select>
</div>
<div class="form-group">
    <label for="description">Description</label>
    <textarea class="form-control" id="description" name="description" rows="3" placeholder="Enter description..."><?php echo e(isset($term) ? $term->taxonomy->description : ''); ?></textarea>
</div>