<?php $__env->startSection('title'); ?> Users <?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
    <link href="<?php echo e(asset('admin_tmpl/css/bootstrap-switch.min.css')); ?>" rel="stylesheet" type="text/css"/>
    <link href="<?php echo e(asset('admin_tmpl/css/datatables.min.css')); ?>" rel="stylesheet" type="text/css"/>
    <link href="<?php echo e(asset('admin_tmpl/css/datatables.bootstrap.css')); ?>" rel="stylesheet" type="text/css"/>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="users_listing_page">
        <!-- BEGIN PAGE TITLE-->
        <h1 class="page-title"> Manage Users
            <small>Here you can create, edit and delete some user</small>
        </h1>
        <!-- END PAGE TITLE-->

        <div class="clearfix add_user_box">
            <div class="col-md-6">
                <div class="btn-group">
                    <a href="<?php echo e(url('/admin/users/create')); ?>" class="btn sbold green"><i class="fa fa-plus"></i> Add New User</a>
                </div>
            </div>
        </div>

        <!-- BEGIN EXAMPLE TABLE PORTLET-->
        <div class="portlet box white">
            <div class="portlet-title">
                <div class="caption">
                    <i class="fa fa-group"></i>Users table</div>
                <div class="tools"> </div>
            </div>
            <div class="portlet-body">
                <table class="table table-striped table-bordered table-hover" id="users_table">
                    <thead>
                        <tr>
                            <th> User Name </th>
                            <th> Email </th>
                            <th> User Role </th>
                            <th> Status </th>
                            <th> Created </th>
                            <th> Actions </th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if($users): ?>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td> <?php echo e($user->name); ?> </td>
                                    <td> <?php echo e($user->email); ?> </td>
                                    <td>
                                        <?php if($user->roles): ?>
                                            <?php $__currentLoopData = $user->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php echo e($role->name); ?>

                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php $status = $user->status ?>
                                        <?php if( $status == 1 ): ?>
                                            <span class="label label-sm label-success"> Approved </span>
                                        <?php elseif( $status == 2 ): ?>
                                            <span class="label label-sm label-warning"> Panding </span>
                                        <?php elseif( $status == 3 ): ?>
                                            <span class="label label-sm label-danger"> Blocked </span>
                                        <?php endif; ?>
                                    </td>
                                    <td> <?php echo e(date('d M. Y', strtotime($user->created_at))); ?> </td>
                                    <td>
                                        <div class="btn-group">
                                            <button class="btn btn-xs blue-chambray dropdown-toggle" type="button" data-toggle="dropdown" aria-expanded="false"> Actions
                                                <i class="fa fa-angle-down"></i>
                                            </button>
                                            <ul class="dropdown-menu pull-left" role="menu">
                                                <li>
                                                    <a href="<?php echo e(url("admin/users/$user->id/edit")); ?>">
                                                        <i class="fa fa-file-text"></i> Edit User </a>
                                                </li>
                                                <li>
                                                    <?php if($user->id != 1): ?>
                                                        <a href="javascript:void(0);" onclick="userDelete(this);" >
                                                        <?php echo Form::open(['method' => 'DELETE', 'route' => ['users.destroy', $user->id]]); ?>

                                                        <i class="fa fa-trash"></i> Delete User
                                                        <?php echo Form::close(); ?>

                                                        </a>
                                                    <?php endif; ?>

                                                </li>
                                            </ul>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <!-- END EXAMPLE TABLE PORTLET-->
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
    <script src="<?php echo e(asset('admin_tmpl/js/datatable.js')); ?>" type="text/javascript"></script>
    <script src="<?php echo e(asset('admin_tmpl/js/datatables.min.js')); ?>" type="text/javascript"></script>
    <script src="<?php echo e(asset('admin_tmpl/js/datatables.bootstrap.js')); ?>" type="text/javascript"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>