<?php $__env->startSection('title'); ?> Search <?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="search_page">
        <!-- BEGIN PAGE TITLE-->
        <h1 class="page-title"> Search Results <?php echo e($posts->count()); ?>

            <small>for <b class="laracus_color"><?php echo e($text); ?></b></small>
        </h1>
        <!-- END PAGE TITLE-->

        <div class="search-bar ">
            <div class="row">
                <div class="col-md-12">
                    <?php echo Form::open(['url' => '/admin/search', 'method' => 'get', 'class' => 'sidebar-search']); ?>

                    <div class="input-group">
                        <input type="text"  name="text" class="form-control" placeholder="Search for...">
                        <span class="input-group-btn">
                            <button class="btn blue uppercase bold" type="submit">Search</button>
                        </span>
                    </div>
                    <?php echo Form::close(); ?>

                </div>
            </div>
        </div>

        <div class="search-container">
            <ul class="search-container">
                <?php if($posts->count()): ?>
                    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="search-item clearfix">
                        <div class="search-content text-left">
                            <div class="row">
                                <div class="col-md-8 col-sm-7 col-xs-9">
                                    <h2 class="search-title">
                                        <a href="<?php echo e($post->url()); ?>" target="_blank"><?php echo e($post->title); ?></a>
                                    </h2>
                                </div>
                                <div class="col-md-4 col-sm-5 col-xs-3 action">
                                    <span> <?php echo e($post->created_at->format('d M Y')); ?></span>
                                    <a href="<?php echo e(url("admin/posts/$post->id/edit")); ?>" class="btn btn-xs yellow">
                                        <i class="fa fa-edit"></i>Edit
                                    </a>
                                </div>
                            </div>
                            <?php if($post->seo_description): ?>
                            <p class="search-desc"><?php echo e($post->seo_description); ?></p>
                            <?php endif; ?>
                        </div>
                    </li>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <li class="search-item clearfix">
                        <div class="search-content text-center">
                            No search results for: <b><?php echo e($text); ?></b>
                        </div>
                    </li>

                <?php endif; ?>
            </ul>
        </div>



    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>