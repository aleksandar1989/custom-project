
// init background slide images
$.backstretch([
		"/admin_tmpl/images/login/1.jpg",
		"/admin_tmpl/images/login/2.jpg",
		"/admin_tmpl/images/login/3.jpg",
		"/admin_tmpl/images/login/4.jpg"
	], {
		fade: 1000,
		duration: 8000
	}
);


