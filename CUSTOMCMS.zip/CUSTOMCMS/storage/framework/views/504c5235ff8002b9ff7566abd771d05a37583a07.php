<?php $__env->startSection('title'); ?> Language Create <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="add_languages_page">

        <h1 class="page-title"> Create New Language
            <small>Here you can create new language</small>
        </h1>
        <!-- END PAGE TITLE-->


        <!-- form start -->
        <?php echo Form::open(['url' => 'admin/languages']); ?>


        <div class="box-body">

            <div class="form-group <?php echo e($errors->has('code') ? 'has-error' : ''); ?>">
                <label for="code">Code</label>
                <?php echo Form::text('code', null, ['class' => 'form-control', 'id' => 'code', 'placeholder' => 'Enter code...']); ?>

                <?php if($errors->first('code')): ?>
                    <span class="help-block"><?php echo e($errors->first('code')); ?></span>
                <?php endif; ?>
            </div>

            <div class="form-group <?php echo e($errors->has('name') ? 'has-error' : ''); ?>">
                <label for="name">Name</label>
                <?php echo Form::text('name', null, ['class' => 'form-control', 'id' => 'name', 'placeholder' => 'Enter name...']); ?>

                <?php if($errors->first('name')): ?>
                    <span class="help-block"><?php echo e($errors->first('name')); ?></span>
                <?php endif; ?>
            </div>

        </div><!-- /.box-body -->

        <div class="box-footer">
            <button type="submit" class="btn btn green pull-right">Save</button>
        </div>

        <?php echo Form::close(); ?>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>