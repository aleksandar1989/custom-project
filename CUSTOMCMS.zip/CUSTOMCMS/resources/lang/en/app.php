<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Global Language Lines
    |--------------------------------------------------------------------------
    |
    |
    */

    'Login' => 'Login',
    'Register' => 'Register',
    'Welcome' => 'Welcome!',
    'Login to your account' => 'Login to your account',
    'Enter any username and password.' => 'Enter any username and password.',

];
