<?php $__env->startSection('title'); ?> Slider Update <?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
    <link href="<?php echo e(asset('admin_tmpl/css/bootstrap-fileinput.css')); ?>" rel="stylesheet" type="text/css"/>
    <link href="<?php echo e(asset('admin_tmpl/css/bootstrap-switch.min.css')); ?>" rel="stylesheet" type="text/css"/>
    <link href="<?php echo e(asset('admin_tmpl/css/datatables.min.css')); ?>" rel="stylesheet" type="text/css"/>
    <link href="<?php echo e(asset('admin_tmpl/css/datatables.bootstrap.css')); ?>" rel="stylesheet" type="text/css"/>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="slider_create_page">
        <!-- BEGIN PAGE TITLE-->
        <h1 class="page-title"> Create Slider
            <small>Here you can create new slider or banner</small>
        </h1>
        <!-- END PAGE TITLE-->


        <div class="sliders_form">
            <?php echo Form::model($slider, ['method' => 'PATCH', 'files' => true, 'action' => ['Admin\SlidersController@update', $slider->id]]); ?>

            <?php echo Form::hidden('id', $slider->id); ?>

            <?php echo $__env->make('admin.sliders.form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <div class="form-actions">
                <button type="submit" class="btn green">Update</button>
            </div>
            <?php echo Form::close(); ?>

        </div>

        <?php if(isset($slider) && $slider->image): ?>
            <div class="edit_image_preview">
                <h1><?php echo e($slider->type); ?> image preview</h1>
                <img src="<?php echo e(asset("images/$slider->type/$slider->image")); ?>" alt="<?php echo e($slider->title); ?>" />
            </div>
        <?php endif; ?>

    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
    <script src="<?php echo e(asset('admin_tmpl/js/bootstrap-fileinput.js')); ?>" type="text/javascript"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>