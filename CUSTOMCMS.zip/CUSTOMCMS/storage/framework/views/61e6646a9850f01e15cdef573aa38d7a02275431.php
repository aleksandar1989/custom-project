<?php $__env->startSection('title'); ?> User Create <?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
    <link href="<?php echo e(asset('admin_tmpl/css/bootstrap-fileinput.css')); ?>" rel="stylesheet" type="text/css"/>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="user_create_page">
        <!-- BEGIN PAGE TITLE-->
        <h1 class="page-title"> Create User
            <small>Here you can create new user</small>
        </h1>
        <!-- END PAGE TITLE-->


        <!-- BEGIN SAMPLE FORM PORTLET-->
        <div class="portlet light bordered">
            <div class="portlet-body form">
                <?php echo Form::open(['url' => 'admin/users', 'files' => true]); ?>


                    <div class="form-body">
                        <?php echo $__env->make('admin.users.form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    </div>

                    <div class="form-actions">
                        <button type="submit" class="btn green">Save</button>
                    </div>
                <?php echo Form::close(); ?>




            </div>
        </div>
        <!-- END SAMPLE FORM PORTLET-->


    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
    <script src="<?php echo e(asset('admin_tmpl/js/bootstrap-fileinput.js')); ?>" type="text/javascript"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>