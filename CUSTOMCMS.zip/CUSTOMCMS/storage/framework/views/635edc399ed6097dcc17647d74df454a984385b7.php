<?php $__env->startSection('title'); ?> User Create <?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
    <link href="<?php echo e(asset('admin_tmpl/css/bootstrap-fileinput.css')); ?>" rel="stylesheet" type="text/css"/>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="user_create_page">
        <h1 class="page-title"> Edit User
            <small>Here you can edit user</small>
        </h1>

        <div class="portlet light bordered">
            <div class="portlet-body form">
                <?php echo Form::model($user, ['method' => 'PATCH', 'files' => true, 'action' => ['Admin\UsersController@update', $user->id]]); ?>

                <?php echo Form::hidden('id', $user->id); ?>


                <div class="form-body">
                    <?php echo $__env->make('admin.users.form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                </div>

                <div class="form-actions">
                    <button type="submit" class="btn green">Update</button>
                </div>
                <?php echo Form::close(); ?>


            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
    <script src="<?php echo e(asset('admin_tmpl/js/bootstrap-fileinput.js')); ?>" type="text/javascript"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>