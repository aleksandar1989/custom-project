<?php $__env->startSection('title'); ?> Create Page <?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
    <link href="<?php echo e(asset('admin_tmpl/css/bootstrap-datetimepicker.min.css')); ?>" rel="stylesheet" type="text/css"/>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="create_post_page">
        <!-- form start -->
        <?php echo Form::open(['url' => 'admin/posts']); ?>

            <?php echo $__env->make('admin.pages.form', ['action' => 'Post', 'type' => 'page'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo Form::close(); ?>

    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
    <script src="<?php echo e(asset('admin_tmpl/plugins/tinymce/tinymce.min.js')); ?>" type="text/javascript"></script>
    <script src="<?php echo e(asset('admin_tmpl/js/bootstrap-datetimepicker.min.js')); ?>" type="text/javascript"></script>
    <script src="<?php echo e(asset('admin_tmpl/js/components-date-time-pickers.js')); ?>" type="text/javascript"></script>
    <script src="<?php echo e(asset('admin_tmpl/plugins/input-mask/jquery.inputmask.js')); ?>" type="text/javascript"></script>
    <script src="<?php echo e(asset('admin_tmpl/plugins/input-mask/jquery.inputmask.date.extensions.js')); ?>" type="text/javascript"></script>
    <script src="<?php echo e(asset('admin_tmpl/plugins/input-mask/jquery.inputmask.extensions.js')); ?>" type="text/javascript"></script>
    <script src="<?php echo e(asset('admin_tmpl/js/post.js')); ?>" type="text/javascript"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>