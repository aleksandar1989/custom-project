<div class="row">
    <div class="col-lg-9">
        <div class="main-content bordered blog-container">
            <div class="head">
                <h1 class="main_title"><?php echo e($action == 'Post' ? 'Add New' : 'Edit'); ?> <?php echo e(ucwords($type)); ?> <small>Here you can create new <?php echo e($type); ?></small></h1>
                <div class="post_date">
                    <i class="icon-calendar font-blue"></i>
                    <?php echo e(date('M d, Y')); ?>

                </div>
            </div>

            <?php echo $__env->make('admin.posts.form.main_box', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        </div>
    </div>
    <div class="col-lg-3">
        <div class="sidebar bordered blog-container">

            <?php echo $__env->make('admin.posts.form.publish_box', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <?php echo $__env->make('admin.posts.form.attributes_box', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        </div>
    </div>
</div>