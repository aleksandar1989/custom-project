<?php $__env->startSection('title'); ?> Users <?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
    <link href="<?php echo e(asset('admin_tmpl/css/bootstrap-switch.min.css')); ?>" rel="stylesheet" type="text/css"/>
    <link href="<?php echo e(asset('admin_tmpl/css/datatables.min.css')); ?>" rel="stylesheet" type="text/css"/>
    <link href="<?php echo e(asset('admin_tmpl/css/datatables.bootstrap.css')); ?>" rel="stylesheet" type="text/css"/>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="users_listing_page">
        <!-- BEGIN PAGE TITLE-->
        <h1 class="page-title"> Manage Pages
            <small>Here you can create, edit and delete pages</small>
        </h1>
        <!-- END PAGE TITLE-->

        <div class="clearfix add_user_box">
            <div class="col-md-6">
                <div class="btn-group">
                    <a href="<?php echo e(url('/admin/pages/create')); ?>" class="btn sbold green"><i class="fa fa-plus"></i> Add New Page</a>
                </div>
            </div>
        </div>

        <!-- BEGIN EXAMPLE TABLE PORTLET-->
        <div class="portlet box white">
            <div class="portlet-title">
                <div class="caption">
                    <i class="fa fa-group"></i>Pages table</div>
                <div class="tools"> </div>
            </div>
            <div class="portlet-body">
                <table class="table table-striped table-bordered table-hover" id="pages_table">
                    <thead>
                    <tr>
                        <th> Title </th>
                        <th>Author</th>
                        <th>Published at</th>
                        <th> Actions </th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php if($posts->count()): ?>
                        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td> <?php echo e($post->title); ?> </td>
                                <td class="author"><a href="/admin/users/<?php echo e($post->user->id); ?>/edit"><?php echo e($post->user->name); ?></a></td>
                                <td>
                                    <?php echo e($post->published_at); ?>

                                </td>
                                <td>
                                    <div class="btn-group">
                                        <button class="btn btn-xs blue-chambray dropdown-toggle" type="button" data-toggle="dropdown" aria-expanded="false"> Actions
                                            <i class="fa fa-angle-down"></i>
                                        </button>
                                        <ul class="dropdown-menu pull-left" role="menu">
                                            <li>
                                                <a href="<?php echo e(url("admin/posts/$post->id/edit")); ?>">
                                                    <i class="fa fa-file-text"></i> Edit Page </a>
                                            </li>
                                            <li>
                                                <a href="javascript:void(0);" onclick="postDelete(this);" >
                                                    <?php echo Form::open(['method' => 'DELETE', 'route' => ['posts.destroy', $post->id]]); ?>

                                                    <i class="fa fa-trash"></i> Delete Page
                                                    <?php echo Form::close(); ?>

                                                </a>
                                            </li>
                                            <li class="divider"> </li>
                                            <li>
                                                <a href="<?php echo e(url("/$post->slug")); ?>">
                                                    <i class="fa fa-link"></i> Preview Page </a>
                                            </li>
                                        </ul>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <!-- END EXAMPLE TABLE PORTLET-->
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
    <script src="<?php echo e(asset('admin_tmpl/js/datatable.js')); ?>" type="text/javascript"></script>
    <script src="<?php echo e(asset('admin_tmpl/js/datatables.min.js')); ?>" type="text/javascript"></script>
    <script src="<?php echo e(asset('admin_tmpl/js/datatables.bootstrap.js')); ?>" type="text/javascript"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>