<?php $__env->startSection('header'); ?>
    <link href="<?php echo e(asset('admin_tmpl/css/login.css')); ?>" rel="stylesheet" type="text/css"/>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- BEGIN LOGO -->
    <div class="login">
        <div class="logo">
            <a href="/">
                <img src="<?php echo e(asset('admin_tmpl/images/logo-big.png')); ?>" alt=""/> </a>
        </div>
        <!-- END LOGO -->
        <!-- BEGIN LOGIN -->
        <div class="content">
            <!-- BEGIN REGISTRATION FORM -->
            <form class="register-form"  method="POST" action="<?php echo e(route('register')); ?>">
                <?php echo e(csrf_field()); ?>

                <h3>Register</h3>
                <p> Enter your personal details below: </p>
                <div class="form-group <?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                    <label class="control-label visible-ie8 visible-ie9">Full Name</label>
                    <div class="input-icon">
                        <i class="fa fa-font"></i>
                        <input class="form-control placeholder-no-fix" type="text" placeholder="Full Name"
                               name="name" value="<?php echo e(old('name')); ?>" required autofocus/>
                        <?php if($errors->has('name')): ?>
                            <span class="help-block">
                                <?php echo e($errors->first('name')); ?>

                            </span>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="form-group <?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                    <!--ie8, ie9 does not support html5 placeholder, so we just show field title for that-->
                    <label class="control-label visible-ie8 visible-ie9">Email</label>
                    <div class="input-icon">
                        <i class="fa fa-envelope"></i>
                        <input class="form-control placeholder-no-fix" type="text" placeholder="Email" name="email" value="<?php echo e(old('email')); ?>" required/>
                        <?php if($errors->has('email')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('email')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                </div>


                <div class="form-group <?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                    <label class="control-label visible-ie8 visible-ie9">Password</label>
                    <div class="input-icon">
                        <i class="fa fa-lock"></i>
                        <input class="form-control placeholder-no-fix" type="password" autocomplete="off"
                               id="password" placeholder="Password" name="password" required/>
                        <?php if($errors->has('password')): ?>
                            <span class="help-block">
                                <?php echo e($errors->first('password')); ?>

                            </span>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="form-group">
                    <label class="control-label visible-ie8 visible-ie9">Confirm Password</label>
                    <div class="controls">
                        <div class="input-icon">
                            <i class="fa fa-check"></i>
                            <input class="form-control placeholder-no-fix" type="password" autocomplete="off"
                                   placeholder="Confirm Password" name="password_confirmation"/></div>
                    </div>
                </div>
                <div class="form-actions">
                    <button type="submit" id="register-submit-btn" class="btn green"> Sign Up</button>
                </div>
            </form>
            <!-- END REGISTRATION FORM -->
        </div>
        <!-- END LOGIN -->
        <!-- BEGIN COPYRIGHT -->
        <div class="copyright"> <?= date('Y') ?> &copy; Laracus - Registration page</div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('footer'); ?>
    <script src="<?php echo e(asset('admin_tmpl/js/jquery.backstretch.min.js')); ?>" type="text/javascript"></script>
    <script src="<?php echo e(asset('admin_tmpl/js/login.js')); ?>" type="text/javascript"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('auth.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>