<div class="form-group  <?php echo e($errors->has('name') ? 'has-error' : ''); ?>">
    <label class="control-label">User Name</label>
    <?php echo Form::text('name', null, ['class' => 'form-control', 'id' => 'name', 'placeholder' => 'Enter your name...']); ?>

    <?php if($errors->first('name')): ?>
        <span class="help-block"><?php echo e($errors->first('name')); ?></span>
    <?php endif; ?>
</div>
<div class="form-group <?php echo e($errors->has('email') ? 'has-error' : ''); ?>">
    <label class="control-label">Email Address</label>
    <div class="input-group">
    <?php echo Form::email('email', null, ['class' => 'form-control', 'id' => 'email', 'placeholder' => 'Enter email...']); ?>

    <span class="input-group-addon">
    <i class="fa fa-envelope"></i>
    </span>
    </div>
    <?php if($errors->first('email')): ?>
        <span class="help-block"><?php echo e($errors->first('email')); ?></span>
    <?php endif; ?>
</div>
<div class="form-group <?php echo e($errors->has('role') ? 'has-error' : ''); ?>">
    <label class="control-label">User role</label>
    <?php echo Form::select('role', $roles, isset($user) ? $user->roles->pluck('id')->toArray() : null, ['class' => 'form-control', 'id' => 'role',  'placeholder' => 'Choose user role...']); ?>

    <?php if($errors->first('role')): ?>
        <span class="help-block"><?php echo e($errors->first('role')); ?></span>
    <?php endif; ?>
</div>
<div class="form-group">
    <label>User status</label>
    <?php echo Form::select('status', [ '1' => 'Active', '2' => 'Panding', '3' => 'Blocked' ], null, ['class' => 'form-control', 'id' => 'role']); ?>

</div>

<div class="form-group  <?php echo e($errors->has('password') ? 'has-error' : ''); ?>">
    <label for="Password" class="control-label">Password</label>
    <div class="input-group">
        <?php echo Form::input('password', 'password', null, ['class' => 'form-control', 'id' => 'password', 'placeholder' => 'Enter password...']); ?>

        <span class="input-group-addon">
            <i class="fa fa-user font-silver"></i>
        </span>
    </div>
    <?php if($errors->first('password')): ?>
        <span class="help-block"><?php echo e($errors->first('password')); ?></span>
    <?php endif; ?>
</div>

<div class="form-group">
    <label for="password_confirmation" class="control-label"> Password Confirm</label>
    <div class="input-group">
        <?php echo Form::input('password', 'password_confirmation', null, ['class' => 'form-control', 'id' => 'password_confirmation', 'placeholder' => 'Enter password confirmation...']); ?>

        <span class="input-group-addon">
            <i class="fa fa-user font-silver"></i>
        </span>
    </div>
</div>

<div class="form-group <?php echo e($errors->has('avatar') ? 'has-error' : ''); ?>">
    <label for="avatar" class="control-label">Avatar</label>
    <div class="fileinput fileinput-new avatar_box" data-provides="fileinput">
        <div class="input-group input-large">
            <div class="form-control uneditable-input input-fixed input-large" data-trigger="fileinput">
                <i class="fa fa-file fileinput-exists"></i>&nbsp;
                <span class="fileinput-filename"> </span>
            </div>
            <span class="input-group-addon btn default btn-file">
                <span class="fileinput-new"> Select image </span>
                <span class="fileinput-exists"> Change </span>
                <?php echo Form::file('avatar'); ?>

            </span>
            <a href="javascript:;" class="input-group-addon btn red fileinput-exists" data-dismiss="fileinput"> Remove </a>
        </div>
    </div>
    <?php if($errors->first('avatar')): ?>
        <span class="help-block"><?php echo e($errors->first('avatar')); ?></span>
    <?php endif; ?>
</div>

<?php if(isset($user) && $user->meta('avatar')): ?>
    <img src="<?php echo e($user->meta('avatar')); ?>" alt="<?php echo e($user->name); ?>" height="100" />
<?php endif; ?>