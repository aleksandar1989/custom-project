<?php if(Session::has('message')): ?>
    <script>
        var type = "<?php echo e(Session::get('type')); ?>";
        var message = "<?php echo e(Session::get('message')); ?>";
        toastr[type](message);
    </script>
<?php endif; ?>